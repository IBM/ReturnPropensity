from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd

class TypeSelector(BaseEstimator, TransformerMixin):
    def __init__(self, dtype):
        self.dtype = dtype
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        assert isinstance(X, pd.DataFrame)
        return X.select_dtypes(include=[self.dtype])

class StringIndexer(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        assert isinstance(X, pd.DataFrame)
        return X.apply(lambda s: s.cat.codes.replace(
            {-1: len(s.cat.categories)}
        ))
class ConvToCategorical(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
       return self
    def transform(self,X):
        assert isinstance(X, pd.DataFrame)
        qual = list( X.loc[:,X.dtypes == 'object'].columns.values )
        for col in qual:
            X[col] = X[col].astype('category')
        return X