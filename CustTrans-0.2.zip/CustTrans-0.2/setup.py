from setuptools import setup

VERSION='0.1'
setup(name='CustTrans',
      version=VERSION,
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=['CustomTransformer'],
      install_requires=[ 'sklearn','pandas','scikit-multilearn'],
      zip_safe=False)
